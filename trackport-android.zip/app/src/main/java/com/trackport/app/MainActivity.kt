package com.trackport.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private val host = "appassets.androidplatform.net"

    private val bridgeJs = """
(function(){
  if (window.__tpBridge) return; window.__tpBridge = true;
  function save(name, href){
    fetch(href).then(function(r){ return r.blob(); }).then(function(b){
      var fr = new FileReader();
      fr.onloadend = function(){ TPApp.saveFile(name || 'trackport-file', fr.result); };
      fr.readAsDataURL(b);
    }).catch(function(){ TPApp.toast('Could not save the file'); });
  }
  window.__tpSave = save;
  var oc = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    if (this.hasAttribute('download') && /^(blob:|data:)/.test(this.href)) { save(this.getAttribute('download'), this.href); return; }
    return oc.apply(this, arguments);
  };
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (a && /^(blob:|data:)/.test(a.href)) { e.preventDefault(); save(a.getAttribute('download'), a.href); }
  }, true);
  window.print = function(){ TPApp.print(); };
  try { Object.defineProperty(navigator, 'share', { configurable: true, value: function(d){
    d = d || {}; TPApp.share([d.title, d.text, d.url].filter(Boolean).join('\n')); return Promise.resolve(); } }); } catch(e) {}
  try { Object.defineProperty(navigator, 'canShare', { configurable: true, value: function(){ return false; } }); } catch(e) {}
  try {
    if (window.firebase && firebase.auth && firebase.auth.Auth) {
      firebase.auth.Auth.prototype.signInWithPopup = function(){
        return Promise.reject({ code: 'auth/operation-not-supported-in-this-environment',
          message: 'Google sign-in is not available in the app yet. Please use email and password.' });
      };
    }
  } catch(e) {}
})();
"""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            textZoom = 100
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setGeolocationEnabled(true)
        }
        web.addJavascriptInterface(Bridge(), "TPApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                if (request.url.host == host) return false
                return openExternal(request.url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(bridgeJs, null)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { startActivityForResult(p.createIntent(), 11); true }
                catch (e: Exception) { fileCb = null; cb.onReceiveValue(null); false }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    cb.invoke(origin, true, false)
                } else {
                    geoOrigin = origin; geoCb = cb
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 12)
                }
            }
        }
        web.setDownloadListener(DownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) web.evaluateJavascript("window.__tpSave && window.__tpSave('trackport-file','" + url + "')", null)
            else if (url.startsWith("http")) openExternal(Uri.parse(url))
        })
        web.loadUrl("https://$host/assets/index.html")
    }

    private fun openExternal(u: Uri): Boolean {
        try { startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast("No app can open this link") }
        return true
    }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 11) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 12) {
            geoCb?.invoke(geoOrigin, res.isNotEmpty() && res.any { it == PackageManager.PERMISSION_GRANTED }, false)
            geoCb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun doPrint() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("TrackPort", web.createPrintDocumentAdapter("TrackPort"), PrintAttributes.Builder().build())
    }

    inner class Bridge {
        @JavascriptInterface fun toast(m: String) { this@MainActivity.toast(m) }

        @JavascriptInterface fun print() { runOnUiThread { doPrint() } }

        @JavascriptInterface fun share(text: String) {
            runOnUiThread {
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Share"))
            }
        }

        @JavascriptInterface fun saveFile(name: String, dataUrl: String) {
            try {
                val comma = dataUrl.indexOf(',')
                val meta = dataUrl.substring(5, comma)
                val mime = meta.substringBefore(';').ifBlank { "application/octet-stream" }
                val body = dataUrl.substring(comma + 1)
                val bytes = if (meta.contains("base64")) Base64.decode(body, Base64.DEFAULT) else Uri.decode(body).toByteArray()
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safe)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TrackPort")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                    toast("Saved to Downloads/TrackPort: $safe")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                    File(dir, safe).writeBytes(bytes)
                    toast("Saved to ${dir.path}")
                }
            } catch (e: Exception) { toast("Save failed: ${e.message}") }
        }
    }
}
