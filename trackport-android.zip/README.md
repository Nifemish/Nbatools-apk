# TrackPort Android
WebView wrapper around the bundled index.html (app/src/main/assets/index.html).
To update the app: replace that file, rebuild. Signed with the bundled keystore so new builds install over old ones.
Keep the repo PRIVATE: the keystore is included for convenience and is only meant for personal sideloading.
